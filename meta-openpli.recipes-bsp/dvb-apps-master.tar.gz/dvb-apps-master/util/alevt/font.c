#define static /* I want them global */
#include "font1.xbm"
#include "font2.xbm"
#include "font3.xbm"
#include "font4.xbm"
