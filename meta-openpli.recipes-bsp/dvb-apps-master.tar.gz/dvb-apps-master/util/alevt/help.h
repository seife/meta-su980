#ifndef HELP_H
#define HELP_H

#include "vt.h"

extern struct vt_page help_pages[];
extern const int nr_help_pages;
#endif
